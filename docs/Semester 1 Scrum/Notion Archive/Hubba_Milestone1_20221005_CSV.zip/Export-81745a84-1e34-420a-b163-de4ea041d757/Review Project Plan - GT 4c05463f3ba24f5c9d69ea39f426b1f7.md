# Review Project Plan - GT

Assign: Garrett
Description: -Review BRD and comment any questions or concerns
Effort: 1
Priority: P2
Sprints: Sprint%203%20b3420b04fd6e40f580498d314d595ea6.md
Status: Done
Story: Project%20Plan%20v1%200a6a4e32bcff4379a00a3b4c055f7e32.md
Tag: Task