# Populate Competitors - BT

Assign: Bryan Tran
Date: 09/23/2022
Description: Create the Competitors tab that explains what the competitors service is, and how our service will be different/improved
Effort: 1
Productivity: 0.5
Productivity Log: BT%2079da7891737f4d8384a56c0f6b647831.md
Sprints: Sprint%201%20d66fa0a85732425da1a9452b3b9510a6.md
Status: Done
Story: Hubba%20RFP%20v%201%20771ed77e8aad493ca8fe6198ac1997fb.md
Tag: Task