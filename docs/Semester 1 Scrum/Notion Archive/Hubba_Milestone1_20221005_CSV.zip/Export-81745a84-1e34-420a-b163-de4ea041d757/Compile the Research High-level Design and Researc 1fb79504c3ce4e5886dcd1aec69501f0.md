# Compile the Research High-level Design and Research High-level Design Document Format - KD

Assign: Kevin Dinh
Effort: 2
Priority: P5
Sprints: Sprint%203%20b3420b04fd6e40f580498d314d595ea6.md
Status: Done
Story: High-Level%20Design%20Document%20v1%20712615b63bd043b4ad96eb5373ec2850.md
Tag: Task