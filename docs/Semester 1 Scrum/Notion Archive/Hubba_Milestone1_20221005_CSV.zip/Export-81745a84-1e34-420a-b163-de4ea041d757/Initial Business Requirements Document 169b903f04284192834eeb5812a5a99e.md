# Initial Business Requirements Document

Current Sprint: No
Descoped date: 09/26/2022
Due: 10/05/2022
Milestone: Milestone%201%20da40f3a1468c4ba6b3e76a3ab854a646.md
Planning Effort: 5
Productivity: TN%20fa17ce0654fe411bb885323ec82bbdd9.md, TN%20667f31a236d540c997b07951826da641.md
Sprints: Sprint%201%20896fe52f9f3c41b8a7fec6630d9b1876.md
Status: Descoped
Tags: Story

[Tasking Out M1](Tasking%20Out%20M1%20c86259b4054a4dcb97737d2a0ec4d2ff.csv)