# Sep 21-Late Night

Created: September 21, 2022 11:23 PM
Last Edited Time: September 28, 2022 11:00 AM
Participants: Anonymous, Anonymous, Anonymous, Anonymous, Anonymous
Type: Ad Hoc, Sprint planning

# Goals

- Sprint Planning

# Discussion Items

- Run through Notion
- Jett takes over capacity calculation
    - Tasking out based on User Story
        1. RFP v.4.0
        2. Initial BRD
    - Each Estimate story effort
    - Vote for RFP effort: 25 hours
    - Vote for Initial BRD: 5hours
- Update Sprint management
- Kanban board for all the single tasks

# Meeting Recording

[https://discord.com/channels/1011468921053925387/1020952355212111922/1022410936197337099](https://discord.com/channels/1011468921053925387/1020952355212111922/1022410936197337099)

[https://www.notion.so](https://www.notion.so)