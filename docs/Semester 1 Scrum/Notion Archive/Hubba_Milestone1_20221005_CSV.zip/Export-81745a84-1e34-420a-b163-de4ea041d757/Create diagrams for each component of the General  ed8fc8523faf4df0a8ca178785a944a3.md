# Create diagrams for each component of the General Behavior/Architecture - BT

Assign: Bryan Tran
Description: Input: Research General Behavior of the System
Effort: 2
Priority: P3
Productivity: 3
Productivity Log: BT%20458fb9f8be9d451e9780e5700c61eb90.md, BT%20f4ea4fdab10b45479df682e1c1edd885.md
Sprints: Sprint%203%20b3420b04fd6e40f580498d314d595ea6.md
Status: Done
Story: Research%20High-Level%20Design%2039c5c32464954d1ab6226f64ab78ebd9.md
Tag: Task