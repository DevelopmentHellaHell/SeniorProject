# Add another Feature - BT

Assign: Bryan Tran
Description: - Brainstorm a core feature to add
- Add a scope and value
Effort: 1
Productivity: 1
Productivity Log: BT%20135eb33dad3649e2ad3e3c36235ffa36.md
Sprints: Sprint%202%2087f766b2aea949e0975d92e7109d70fb.md
Status: Done
Story: Hubba%20RFP%20v%201%202%205a17265649a94146be1ce504f17db88e.md
Tag: Task