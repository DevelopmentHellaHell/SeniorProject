# Research High-Level Design

Current Sprint: No
Descoped date: 10/06/2022
Milestone: Milestone%201%20da40f3a1468c4ba6b3e76a3ab854a646.md
Planning Effort: 15
Priority: P3
Productivity: 1%20037b0c6ae0314074b950443bafde772c.md, BT%20fbc4b822f25e4a28a53029a693828f44.md, BT%20f4ea4fdab10b45479df682e1c1edd885.md, BT%20f839f6d0295e48fcab486bf45e055175.md, Untitled%20f7ece497c9e044debba4b6d28814a741.md, DK%203923a7780be342afad5d071cb9a1b547.md
Sprints: Sprint%203%208eeed53a58604858a33e55908e967fd9.md
Status: Descoped
Tags: Story