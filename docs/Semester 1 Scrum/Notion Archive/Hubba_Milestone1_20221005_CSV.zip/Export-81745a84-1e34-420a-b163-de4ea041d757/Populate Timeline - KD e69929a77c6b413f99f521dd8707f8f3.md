# Populate Timeline - KD

Assign: Kevin Dinh
Date: 09/23/2022
Description: Create the timeline for our deliverables after the features are developed
Effort: 1
Productivity: 0.5
Productivity Log: KD%2079e9c5d0f4ca407e8e4d3adf4ce498b3.md
Sprints: Sprint%201%20d66fa0a85732425da1a9452b3b9510a6.md
Status: Done
Story: Hubba%20RFP%20v%201%20771ed77e8aad493ca8fe6198ac1997fb.md
Tag: Task