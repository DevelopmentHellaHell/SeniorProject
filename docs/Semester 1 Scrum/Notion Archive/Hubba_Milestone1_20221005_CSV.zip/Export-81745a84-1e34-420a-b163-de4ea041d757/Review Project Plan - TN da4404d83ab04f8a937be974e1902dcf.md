# Review Project Plan - TN

Assign: Tien
Description: -Review BRD and comment any questions or concerns
Effort: 1
Priority: P2
Productivity: 1
Productivity Log: TN%207a68f00766064319ac6d1aec81438dc3.md
Sprints: Sprint%203%20b3420b04fd6e40f580498d314d595ea6.md
Status: Done
Story: Project%20Plan%20v1%200a6a4e32bcff4379a00a3b4c055f7e32.md
Tag: Task