# TrainE RFP v.1

Current Sprint: No
Descoped date: 09/12/2022
Due: 09/07/2022
Milestone: Project%20Proposal%202dddfa18a72249be8fa5bbd301ae8b34.md
Sprints: Pre_Scrum%20161a2667db884e578402eb8e168f2a67.md
Status: Descoped
Tags: Story

[TrainE_RFP_v1](https://docs.google.com/document/d/1u19c2_ww1ASZGwRfyxawnMmNVYJi2zBQ8TgvK_9l8O8/edit?usp=drivesdk)