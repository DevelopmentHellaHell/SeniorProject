# Project Proposal

Status: Done
Stories: TrainE%20RFP%20v%201%2042d38410158547ebb2ddf1e2a5c5fa4c.md, TrainE%20RFP%20v%202%20cf400c2178274e17a1e8b237340ab969.md, TrainE%20RFP%20v%203%203a31c1cdb3c04314a3dda12938017b99.md, Hubba%20RFP%20v%201%20771ed77e8aad493ca8fe6198ac1997fb.md, Hubba%20RFP%20v%201%202%205a17265649a94146be1ce504f17db88e.md, Hubba%20RFP%20v%201%203%20e9e43ced84894ae7b3eaba0a505fd5ed.md, Hubba%20RFP%20v%201%204%203dfb96ff9b06473f9ea9a0a0f59ad05b.md

<aside>
👋 Learn how to organize tasks by project, coordinate with your team, and track progress.

</aside>

# How to use this template

1. This is your sample project tracker. It contains projects, tasks, and sprints — you can click on the name of the project or task to open it up to its own page where you can add new detail.
    
    ![better templates 4 (5).png](https://www.notion.so/images/app-packages/agile-guide-image1.png)
    
2. Click “+ New” below the sample tasks to add a new task. 
    
    ![better templates 5 (2).png](https://www.notion.so/images/app-packages/agile-guide-image2.png)
    
3. Navigate views using tabs at the top of the database — each one uses the same underlying data but displays it in different ways so that you can quickly and easily keep track of all your team’s happenings.
    
    ![better templates 1 (2).png](https://www.notion.so/images/app-packages/agile-guide-image3.png)
    

# Tasks, Sprints, and Projects

### Tasks

Tasks are the smallest unit of work in your project management tracker. A Task represents a more granular piece of work, often assigned to just one person. Many Tasks can be organized into a Project, or added to a Sprint. 

### Projects

Projects are typically made up of tasks. A Project represents a large body of work, such as a product launch, or a team milestone. A Project can be broken down into many Tasks, and contain customizable properties such as Status. 

### Sprints

Sprints are another dimension by which you can organize tasks and projects, commonly used in Agile workflows. A sprint represents a discrete cycle of time in which tasks will be completed. You can configure start and end dates per Sprint, and assign each Task to a Sprint.

# Adding custom fields

We’ve pre-populated this template with the most common project management fields (like task status and assignee), but you can add your own when you are creating a new field. You’ll have options like priority, dependencies, and sub-tasks.

![image 8 (1).png](https://www.notion.so/images/app-packages/agile-guide-image4.png)

# Views, filters, and sorts

Views are customizable, flexible layouts to visualize your databases and properties as a table, board, calendar, timeline, or list. This template comes with several views of Projects, Tasks, and Sprints — you can customize each or create your own! 

![better templates 2 (1).png](https://www.notion.so/images/app-packages/agile-guide-image5.png)