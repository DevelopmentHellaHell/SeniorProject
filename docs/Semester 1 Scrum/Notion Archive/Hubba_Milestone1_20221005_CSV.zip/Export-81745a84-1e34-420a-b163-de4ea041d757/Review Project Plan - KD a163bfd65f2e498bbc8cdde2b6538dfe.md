# Review Project Plan - KD

Assign: Kevin Dinh
Description: -Review BRD and comment any questions or concerns
Effort: 1
Priority: P2
Productivity: 2.5
Productivity Log: KD%20639ea154bc3e4e48bd34835d4b6fcd9a.md, Untitled%20d5c96616a749441d9d8495522a5e05c8.md, Untitled%20d3c3da94f09145cca5ca2bb32ae2798e.md
Sprints: Sprint%203%20b3420b04fd6e40f580498d314d595ea6.md
Status: Done
Story: Project%20Plan%20v1%200a6a4e32bcff4379a00a3b4c055f7e32.md
Tag: Task