# Milestone 1

Dates: September 12, 2022 → October 5, 2022
Status: Done
Stories: Project%20Plan%20v1%200a6a4e32bcff4379a00a3b4c055f7e32.md, Initial%20Business%20Requirements%20Document%20169b903f04284192834eeb5812a5a99e.md, Research%20High-Level%20Design%2039c5c32464954d1ab6226f64ab78ebd9.md, Business%20Requirements%20Document%20v2%20e951171d0bc74decb5d8739c91825d66.md, Research%20Project%20Plan%20Format%20710d49590234467a9670c2e7659d9e45.md, Research%20High-Level%20Design%20Document%20Format%20bf3ad20091334c0e9ce30e64054d490f.md, High-Level%20Design%20Document%20v1%20712615b63bd043b4ad96eb5373ec2850.md, Project-wide%20Scope%20Requirements%20for%20BRD%204e84ca8b13ec4ec8929723e88b2255b7.md

## About this project

- 

## Project tasks