# Research General Behavior of the system - BT

Assign: Bryan Tran
Description: Document the findings of the general behavior which includes message format, web service style, input validation on frontend and backend, security, type of data storage, database tie-in, reference to error handling
Effort: 2
Priority: P3
Productivity: 3
Productivity Log: BT%20b0ee61c9e34b43faa9ddf20a4d7079fd.md, BT%20fbc4b822f25e4a28a53029a693828f44.md
Sprints: Sprint%203%20b3420b04fd6e40f580498d314d595ea6.md
Status: Done
Story: Research%20High-Level%20Design%2039c5c32464954d1ab6226f64ab78ebd9.md
Tag: Task