# Review BRD - KD

Assign: Kevin Dinh
Description: -Review BRD and comment any questions or concerns
Effort: 2
Priority: P0
Productivity: 6
Productivity Log: Untitled%204579987aee7e46f599389be00ecdff16.md, Untitled%204832d4d81d6b4cdaad3c6c269931d18f.md, Untitled%20101c0326bcec443fa0aeebf9b55b3287.md
Sprints: Sprint%202%2087f766b2aea949e0975d92e7109d70fb.md, Sprint%203%20b3420b04fd6e40f580498d314d595ea6.md
Status: Done
Story: Business%20Requirements%20Document%20v2%20e951171d0bc74decb5d8739c91825d66.md
Tag: Task