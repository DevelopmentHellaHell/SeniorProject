# Research Roadmap

Assign: Jett Sonoda
Description: NOTE: This is for the client, from now to next semester
- Write notes on how to create a Roadmap based on findings of other Roadmap documents
Effort: 2
Productivity: 2
Productivity Log: JS%20b042281f5f16408e817b57b04ef125b6.md, JS%20a5a66517c6954eaa9936ad04f230ae09.md, JS%20611230dc2c2f47b4b29b89112afdc608.md
Sprints: Sprint%202%2087f766b2aea949e0975d92e7109d70fb.md
Status: Done
Story: Research%20Project%20Plan%20Format%20710d49590234467a9670c2e7659d9e45.md
Tag: Task