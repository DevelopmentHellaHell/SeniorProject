# Add Projects templates to Notion

Assign: Garrett
Due: September 26, 2022
Is Current Sprint: No
Project: Getting%20started%20with%20Projects,%20tasks%20&%20sprints%205ac01c86fb3e43849cef9452caca524c.md
Sprint: Sprint%203%20b3420b04fd6e40f580498d314d595ea6.md
Status: Done