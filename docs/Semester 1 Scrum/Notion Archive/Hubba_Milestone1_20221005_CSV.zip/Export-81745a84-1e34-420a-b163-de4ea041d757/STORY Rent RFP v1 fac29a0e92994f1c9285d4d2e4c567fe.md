# STORY: Rent RFP v1

Assign: Good Guy Jett
Date: 09/24/2022
Description: As a team, I want to align project understandings with the client to propose a viable idea.
Effort: 25
Sprints: Sprint%201%20d66fa0a85732425da1a9452b3b9510a6.md
Status: Ship
Story: Hubba%20RFP%20v%201%20771ed77e8aad493ca8fe6198ac1997fb.md
Tag: Story