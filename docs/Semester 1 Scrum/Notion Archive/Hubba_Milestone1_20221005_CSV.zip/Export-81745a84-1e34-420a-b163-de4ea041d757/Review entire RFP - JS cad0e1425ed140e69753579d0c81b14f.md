# Review entire RFP - JS

Assign: Jett Sonoda
Description: - Ensure all sections of the RFP align with the scope
Effort: 0.5
Productivity: 0.5
Productivity Log: JS%203fc9a2fa343d4aa79ee030811da4453b.md
Sprints: Sprint%202%2087f766b2aea949e0975d92e7109d70fb.md
Status: Done
Story: Hubba%20RFP%20v%201%202%205a17265649a94146be1ce504f17db88e.md
Tag: Task