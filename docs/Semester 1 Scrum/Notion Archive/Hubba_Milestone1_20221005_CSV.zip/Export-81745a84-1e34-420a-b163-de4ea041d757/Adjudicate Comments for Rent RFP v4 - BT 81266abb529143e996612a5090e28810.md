# Adjudicate Comments for Rent RFP v4 - BT

Assign: Bryan Tran
Description: Adjudicate comments from Jett and Professor Vong
Should be fully reviewed before submission
Effort: 1
Productivity: 1
Productivity Log: BT%201889c2f871474a4887ede443174bff4d.md
Sprints: Sprint%202%2087f766b2aea949e0975d92e7109d70fb.md
Status: Done
Story: Hubba%20RFP%20v%201%204%203dfb96ff9b06473f9ea9a0a0f59ad05b.md
Tag: Task