# Review RFP - TN

Assign: Tien
Date: 09/23/2022
Description: Review the entire RFP and leave comments on the document
Effort: 1
Productivity: 1
Productivity Log: TN%2048ce0d4137894ef1b9f6c3044deec7fb.md
Sprints: Sprint%201%20d66fa0a85732425da1a9452b3b9510a6.md
Status: Done
Story: Hubba%20RFP%20v%201%20771ed77e8aad493ca8fe6198ac1997fb.md
Tag: Task