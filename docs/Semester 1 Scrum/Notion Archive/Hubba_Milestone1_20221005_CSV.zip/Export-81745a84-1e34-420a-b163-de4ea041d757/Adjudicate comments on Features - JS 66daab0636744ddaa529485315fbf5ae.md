# Adjudicate comments on Features - JS

Assign: Jett Sonoda
Description: - Implementation needs to be removed
- Ensure scope is in the specific category
- Remove Payment System
- Determine impacts of Notification and Messaging System
- Moderation System removed
Effort: 1
Productivity: 0.5
Productivity Log: JS%20eb0a9807ca7c4cd1a661d5448b477b99.md
Sprints: Sprint%202%2087f766b2aea949e0975d92e7109d70fb.md
Status: Done
Story: Hubba%20RFP%20v%201%202%205a17265649a94146be1ce504f17db88e.md
Tag: Task