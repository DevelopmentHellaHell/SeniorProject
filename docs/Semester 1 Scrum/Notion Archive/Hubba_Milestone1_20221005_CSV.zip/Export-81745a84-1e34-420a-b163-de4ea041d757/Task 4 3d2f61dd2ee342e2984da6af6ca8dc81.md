# Task 4

Assign: Garrett
Due: September 23, 2022
Is Current Sprint: Yes
Project: Project%202%20dbcce7ced6d84072a95a6192086f82d2.md
Sprint: Sprint%202%2087f766b2aea949e0975d92e7109d70fb.md
Status: Not Started