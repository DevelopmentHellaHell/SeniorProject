# STORY: Initial Business Requirements Document

Assign: Tien
Date: 09/24/2022
Description: As a team, I want to outline the BRD in order to stay organized when populating the requirements.
Effort: 5
Sprints: Sprint%201%20d66fa0a85732425da1a9452b3b9510a6.md
Status: Done
Story: Initial%20Business%20Requirements%20Document%20169b903f04284192834eeb5812a5a99e.md
Tag: Story