# Review BRD - DK

Assign: Darius Koroni
Description: -Review BRD and comment any questions or concerns
Effort: 2
Priority: P0
Productivity: 6.5
Productivity Log: DK%20ed8c1c478d024bd7bd3b5820b4a6c50b.md, DK%2016c422b07dfb40b6bed3adf7adce4587.md, DK%20e6ba8db70a974c45923ef855655048d4.md
Sprints: Sprint%202%2087f766b2aea949e0975d92e7109d70fb.md, Sprint%203%20b3420b04fd6e40f580498d314d595ea6.md
Status: Done
Story: Business%20Requirements%20Document%20v2%20e951171d0bc74decb5d8739c91825d66.md
Tag: Task