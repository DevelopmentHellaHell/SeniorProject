# Project Plan v1

Current Sprint: No
Descoped date: 10/06/2022
Milestone: Milestone%201%20da40f3a1468c4ba6b3e76a3ab854a646.md
Planning Effort: 15
Priority: P2
Productivity: JS%208833f36c4d2e48f3a4bc00034a6bae5d.md, JS%205de1789940b24b1ca64f8f6d839cd265.md, JS%208bd49cffb8f446fe828877203d2d4202.md, JS%204d289dca9f194c59bca67e5d7fa649a5.md, BT%20b6f77669de8d44a4b45d36dc1f890237.md, KD%20639ea154bc3e4e48bd34835d4b6fcd9a.md, Untitled%20dc5e4604c7de4f43ba585b8ace25d5e4.md, Untitled%20b108a08ae7e14f26b9149d27e0a56631.md, Untitled%20c7279c61c3d446f6874116f676bed666.md, Untitled%2068296c56381841d3830262fe05eddf7b.md, TN%207a68f00766064319ac6d1aec81438dc3.md, Untitled%20d5c96616a749441d9d8495522a5e05c8.md, Untitled%20500b21a6a35541279f059ae770983ab3.md, Untitled%20d3c3da94f09145cca5ca2bb32ae2798e.md
Sprints: Sprint%203%208eeed53a58604858a33e55908e967fd9.md
Status: Descoped
Tags: Story