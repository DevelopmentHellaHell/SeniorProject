# Sept 26-Office hours

Created: September 28, 2022 8:42 PM
Last Edited Time: September 28, 2022 8:45 PM

# eavesdropping

# BRD

- List out all requirements first
- Contract that says "I agree to do it like this"
- No bill of materials yet
- Vong is a stakeholder as the client

# High-level design discussed on Wednesday

- What is architecture of system you are going to deliver
- Need to make design decisions on architecture
- Certain general behaviors you need to decide
- Error handling is example:
    - "input validation error" how is your team going to handle that? General behavior? How will every other feature deal with that?
    - One team might log, one team might not do anything, these are all decisions
- Typically diagrams, when it comes to software
    - Blueprint => not generally just words
    - Picture or diagram with words
- Work flow is good high level way to diagram
- Class diagram for classes but not high level, very low level
- They are not UML diagram, just industry standard way
    - Kinda like state diagram but need to make it more high level
- Don’t say "here's a diagram"
    - Cover page
    - Diagrams
    - Explanations

# Implementation:

## If you include then the client should specifically ask for it that way

### That is what the BRD is for: exact requirements of how functionality will behave

## Logging in:

### **RFP** Functionalities that require authentication

### **BRD** Authentication will require : username, password, third party key, etc

## BRD should be aligned with client

- Supposed to be agreement of what requirements
- Client should agree with it
    - DO NOT ASSUME EVERYTHING IS CORRECT
- Certain details that should be discussed: scoping
    - Ex: scheduling scope: just one event at a time or multiple at a time
- Unimportant features to not discuss with the client: UI
    - Do not have anything in relationship with what you will develop it
    - NO FUNCTIONALITY in BRD
- Do not necessarily discuss how function will behave with errors
- More detailed BRD = less likely someone will implement it incorrectly

## High level design addresses system as a whole

### Blueprint for system

### Can have divergences but that is for low level design

### "If input validation occurs, our system will handle it like this"

# In-app vs messaging

## Both inform the consumer of something

## Could directly email you

### Out of app will be an additional cost: certain services will require you to pay

## Features to have users communicate

### Not a core user story feature

### Corfe user story feature addresses business side of things or main pain point directly

### Everything else is an off-set of user stories

## Focus on features which align with our CORE

### Business side isn't that useful

### => really hard to explain BRD

### Having more features related to the value

## Move "things" to vision => specialize for now

## We need to focus on how to do the listings to make it more unique to everyone else

### Niche of workspace

### Barber shop rents chair and they don't have to pay for whole thing

### Hobbyists or those who already have the skills and want to make a business or living

# Logging => "I will log these activities and I will not log these"

# Priorities (should all be unique):

1. Proposal
2. BRD
3. Project plan
4. High level

# Kanban board is typically only tasks