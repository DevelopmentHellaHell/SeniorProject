# Research Architecture of the system - JS

Assign: Jett Sonoda
Description: Document the findings of the architecture
Effort: 2
Priority: P3
Productivity: 1
Productivity Log: 1%20037b0c6ae0314074b950443bafde772c.md
Sprints: Sprint%203%20b3420b04fd6e40f580498d314d595ea6.md
Status: Done
Story: Research%20High-Level%20Design%2039c5c32464954d1ab6226f64ab78ebd9.md
Tag: Task