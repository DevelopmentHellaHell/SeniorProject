# Hubba RFP v.1.4

Current Sprint: No
Descoped date: 09/28/2022
Milestone: Project%20Proposal%202dddfa18a72249be8fa5bbd301ae8b34.md
Planning Effort: 2
Productivity: JS%20f9459aa27a3046c8934915db721c57e9.md, BT%201889c2f871474a4887ede443174bff4d.md
Sprints: Sprint%202%20427eb1e022d74213aeada09f56425209.md
Status: Descoped
Tags: Story