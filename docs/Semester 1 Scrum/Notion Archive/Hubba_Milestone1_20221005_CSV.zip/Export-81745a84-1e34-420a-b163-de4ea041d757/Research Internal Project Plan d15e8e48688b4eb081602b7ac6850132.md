# Research Internal Project Plan

Assign: Jett Sonoda
Description: NOTE: This is for the team, nearly day-to-day details, from now to next semester
- Write notes on how to create an Internal Project Plan based on findings of other Project Plan documents
Effort: 3
Productivity: 1
Productivity Log: JS%20717184617337401f8b8388370218a4e0.md, JS%202d86be54ae0b4369b770417369a3a086.md
Sprints: Sprint%202%2087f766b2aea949e0975d92e7109d70fb.md
Status: Done
Story: Research%20Project%20Plan%20Format%20710d49590234467a9670c2e7659d9e45.md
Tag: Task