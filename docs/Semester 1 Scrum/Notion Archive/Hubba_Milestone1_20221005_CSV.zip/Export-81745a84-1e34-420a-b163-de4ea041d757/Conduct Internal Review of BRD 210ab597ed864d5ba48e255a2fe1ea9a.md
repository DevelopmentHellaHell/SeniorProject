# Conduct Internal Review of BRD

Assign: Tien
Description: -Ensure all comments and questions are answered
Effort: 1
Priority: P0
Productivity: 8
Productivity Log: TN%20bed00dfabd654593801031fcb5e5a035.md, TN%20a85ab8dbb2a946f3bb27815bd02e2220.md, TN%2001c724fe9957429ea8e9740d9ba9c7fd.md, TN%203e3359552c464941b8fb5ecc793e3100.md
Sprints: Sprint%202%2087f766b2aea949e0975d92e7109d70fb.md, Sprint%203%20b3420b04fd6e40f580498d314d595ea6.md
Status: Done
Story: Business%20Requirements%20Document%20v2%20e951171d0bc74decb5d8739c91825d66.md
Tag: Task