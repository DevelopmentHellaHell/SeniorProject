# Business Requirements Document v2

Current Sprint: No,No
Descoped date: 10/06/2022
Milestone: Milestone%201%20da40f3a1468c4ba6b3e76a3ab854a646.md
Planning Effort: 20
Priority: P0
Productivity: TN%205ec8be4094ec4fde9f68f87b45c2813b.md, DK%20a7e6d0150d3e42c1b7efff4d84c883c7.md, DK%20a52eb2eae57f45c1b7b7beb9cb10b094.md, KD%2094b128e29b134591a5ac9e6db2118fee.md, TN%2029737dec3be548c4bc7a64771a7cd551.md, KD%2006ae6f562dac4c4d877a5ed12aa86cdc.md, DK%2089bace38018b4a00aa5b57f86ab436f4.md, DK%20ed8c1c478d024bd7bd3b5820b4a6c50b.md, DK%20bb158117c2214d779ff2eca2133a119d.md, BT%20a74b99de9b6e4e898b84bb09dbad1955.md, Untitled%201675dccad6454b5a96e299a4a722491f.md, Untitled%2005beba569b8546bcabafad08c2f80b61.md, DK%20c9e457b3d1b24f8a9d8adfd96a33bb73.md, 5%20f902fffc38ac4643aae80b96c5827a9c.md, TN%20bb99e59832f548569498c6d94f5acc7e.md, TN%20bed00dfabd654593801031fcb5e5a035.md, TN%20cd198298edbd41e68d0c3ffa0a587692.md, BT%20b76770822e394552b83d1e2dfc86ae56.md, Untitled%202109505d92c34a55b8d7fbfede6284dd.md, Untitled%204579987aee7e46f599389be00ecdff16.md, DK%2016c422b07dfb40b6bed3adf7adce4587.md, Untitled%2080abf4c48da54d0da752fdef7bb6e05b.md, TN%20a85ab8dbb2a946f3bb27815bd02e2220.md, TN%2001c724fe9957429ea8e9740d9ba9c7fd.md, TN%203e3359552c464941b8fb5ecc793e3100.md, DK%20e6ba8db70a974c45923ef855655048d4.md, DK%204bdca86c91d9439b8c6ff82341bb1990.md, Untitled%204832d4d81d6b4cdaad3c6c269931d18f.md, Untitled%20101c0326bcec443fa0aeebf9b55b3287.md
Sprints: Sprint%202%20427eb1e022d74213aeada09f56425209.md, Sprint%203%208eeed53a58604858a33e55908e967fd9.md
Status: Descoped
Tags: Story