# Hubba RFP v.1.3

Current Sprint: No
Descoped date: 09/27/2022
Milestone: Project%20Proposal%202dddfa18a72249be8fa5bbd301ae8b34.md
Planning Effort: 1
Productivity: BT%20616cb40e3bd14787893b221f47eacfef.md, JS%20664f0a5299d94bda9cd6a1e69c0eccb7.md
Sprints: Sprint%202%20427eb1e022d74213aeada09f56425209.md
Status: Descoped
Tags: Story