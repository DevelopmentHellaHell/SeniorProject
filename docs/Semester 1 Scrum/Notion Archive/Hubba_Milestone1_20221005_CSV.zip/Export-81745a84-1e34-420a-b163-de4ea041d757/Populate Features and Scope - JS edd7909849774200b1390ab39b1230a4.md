# Populate Features and Scope - JS

Assign: Jett Sonoda
Date: 09/23/2022
Description: Create the features, value of each feature, scope, and implementation
Effort: 6
Productivity: 6
Productivity Log: JS%20966fa55bf20647d680533a85fcb83724.md, JS%2099bcaa4121a34e51965939f8804ee449.md
Sprints: Sprint%201%20d66fa0a85732425da1a9452b3b9510a6.md
Status: Done
Story: Hubba%20RFP%20v%201%20771ed77e8aad493ca8fe6198ac1997fb.md
Tag: Task