# Populate Features and Scope -KD

Assign: Kevin Dinh
Date: 09/23/2022
Description: Create the features, value of each feature, scope, and implementation
Effort: 2
Productivity: 4.5
Productivity Log: KD%208261cf0b44f7474b8551ec9f5815311c.md
Sprints: Sprint%201%20d66fa0a85732425da1a9452b3b9510a6.md
Status: Done
Story: Hubba%20RFP%20v%201%20771ed77e8aad493ca8fe6198ac1997fb.md
Tag: Task