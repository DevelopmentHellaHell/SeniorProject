# Populate Competitors - TN

Assign: Tien
Date: 09/23/2022
Description: Create the Competitors tab that explains what the competitors service is, and how our service will be different/improved
Effort: 1
Productivity: 1
Productivity Log: TN%204a9a872ece2242f884463ef466e4a05b.md
Sprints: Sprint%201%20d66fa0a85732425da1a9452b3b9510a6.md
Status: Done
Story: Hubba%20RFP%20v%201%20771ed77e8aad493ca8fe6198ac1997fb.md
Tag: Task