# Conduct Review of Project Plan - JS

Assign: Jett Sonoda
Effort: 1
Priority: P2
Productivity: 0.5
Productivity Log: JS%204d289dca9f194c59bca67e5d7fa649a5.md
Sprints: Sprint%203%20b3420b04fd6e40f580498d314d595ea6.md
Status: Done
Story: Project%20Plan%20v1%200a6a4e32bcff4379a00a3b4c055f7e32.md
Tag: Task