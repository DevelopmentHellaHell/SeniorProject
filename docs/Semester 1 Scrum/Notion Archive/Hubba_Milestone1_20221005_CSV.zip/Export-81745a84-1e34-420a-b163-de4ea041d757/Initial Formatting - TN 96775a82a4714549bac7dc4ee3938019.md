# Initial Formatting - TN

Assign: Tien
Date: 09/23/2022
Description: Create the BRD with skeleton tables and formatting
Effort: 4
Productivity: 4
Productivity Log: TN%20fa17ce0654fe411bb885323ec82bbdd9.md
Sprints: Sprint%201%20d66fa0a85732425da1a9452b3b9510a6.md
Status: Done
Story: Initial%20Business%20Requirements%20Document%20169b903f04284192834eeb5812a5a99e.md
Tag: Task