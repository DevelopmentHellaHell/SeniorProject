# Populate Project Description and Value - GT

Assign: Garrett
Date: 09/23/2022
Description: Create the Project Description and value of our product
Effort: 2
Sprints: Sprint%201%20d66fa0a85732425da1a9452b3b9510a6.md
Status: Done
Story: Hubba%20RFP%20v%201%20771ed77e8aad493ca8fe6198ac1997fb.md
Tag: Task