# Compile to create Google Doc of the High-level design

Assign: Kevin Dinh
Effort: 2.5
Priority: P4
Sprints: Sprint%203%20b3420b04fd6e40f580498d314d595ea6.md
Status: Done
Story: Research%20High-Level%20Design%20Document%20Format%20bf3ad20091334c0e9ce30e64054d490f.md
Tag: Task