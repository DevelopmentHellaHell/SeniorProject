# Adjudicate comments on Features - BT

Assign: Bryan Tran
Description: - Implementation needs to be removed
- Ensure scope is in the specific category
- Remove Payment System
- Determine impacts of Notification and Messaging System
- Moderation System removed
Effort: 1
Productivity: 2
Productivity Log: BT%205abc3ff67fee4405abbc8a106631ccba.md, BT%206b4544bf631441c38f3a0dd38eaa9fd6.md
Sprints: Sprint%202%2087f766b2aea949e0975d92e7109d70fb.md
Status: Done
Story: Hubba%20RFP%20v%201%202%205a17265649a94146be1ce504f17db88e.md
Tag: Task