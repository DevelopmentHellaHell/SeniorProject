# Research High-Level Design Document Format

Current Sprint: No
Descoped date: 10/06/2022
Milestone: Milestone%201%20da40f3a1468c4ba6b3e76a3ab854a646.md
Planning Effort: 5
Priority: P4
Productivity: BT%20458fb9f8be9d451e9780e5700c61eb90.md, BT%20b0ee61c9e34b43faa9ddf20a4d7079fd.md, BT%2042eacd30589e4e69ad81fee31abb793b.md
Sprints: Sprint%203%208eeed53a58604858a33e55908e967fd9.md
Status: Descoped
Tags: Story