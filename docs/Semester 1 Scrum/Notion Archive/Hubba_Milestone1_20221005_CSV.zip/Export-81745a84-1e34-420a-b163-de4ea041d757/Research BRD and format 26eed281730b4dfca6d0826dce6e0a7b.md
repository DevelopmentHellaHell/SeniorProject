# Research BRD and format

Assign: Tien
Date: 09/23/2022
Description: Find example BRDs to read and learn the format and language used.
Effort: 1
Productivity: 1
Productivity Log: TN%20667f31a236d540c997b07951826da641.md
Sprints: Sprint%201%20d66fa0a85732425da1a9452b3b9510a6.md
Status: Done
Story: Initial%20Business%20Requirements%20Document%20169b903f04284192834eeb5812a5a99e.md
Tag: Task