# Research Architecture of the system - DK

Assign: Darius Koroni
Description: Document the findings of the architecture
Effort: 2
Priority: P3
Productivity: 0.5
Productivity Log: DK%203923a7780be342afad5d071cb9a1b547.md
Sprints: Sprint%203%20b3420b04fd6e40f580498d314d595ea6.md
Status: Done
Story: Research%20High-Level%20Design%2039c5c32464954d1ab6226f64ab78ebd9.md
Tag: Task