# Oct 2 Project Plan + BRD Review

Created: October 2, 2022 10:19 PM
Last Edited Time: October 2, 2022 10:21 PM
Participants: Anonymous, Anonymous, Anonymous, Anonymous, Anonymous, Anonymous

Internal project plan review

Assigning users to each task

BRD review

Project wide systems
Questions to ask Vong
Scheduling system overview
Account  system overview

High-level vs Low-level design

Vong's class notes vs what we have currently

Can a single page application has subsites?

What exactly is a single page application?

Running out of space in notion

What to do?