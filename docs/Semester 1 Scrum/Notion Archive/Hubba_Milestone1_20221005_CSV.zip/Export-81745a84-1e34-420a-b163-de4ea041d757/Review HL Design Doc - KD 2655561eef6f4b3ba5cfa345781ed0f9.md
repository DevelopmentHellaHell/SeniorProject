# Review HL Design Doc - KD

Assign: Kevin Dinh
Description: '-Review HL Design Doc and comment any questions or concerns
Effort: 2
Priority: P5
Productivity: 1
Productivity Log: Untitled%20e0f14f8a4bb140e6b699f7375100ef9a.md
Sprints: Sprint%203%20b3420b04fd6e40f580498d314d595ea6.md
Status: Done
Story: High-Level%20Design%20Document%20v1%20712615b63bd043b4ad96eb5373ec2850.md
Tag: Task