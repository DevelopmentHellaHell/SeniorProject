# Create stories/more granular names for the Internal Project Plan - JS

Assign: Jett Sonoda
Effort: 4
Priority: P2
Productivity: 8
Productivity Log: JS%205de1789940b24b1ca64f8f6d839cd265.md, Untitled%20dc5e4604c7de4f43ba585b8ace25d5e4.md, Untitled%2068296c56381841d3830262fe05eddf7b.md
Sprints: Sprint%203%20b3420b04fd6e40f580498d314d595ea6.md
Status: Done
Story: Project%20Plan%20v1%200a6a4e32bcff4379a00a3b4c055f7e32.md
Tag: Task