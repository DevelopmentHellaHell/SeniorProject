# Research Project Plan Format

Current Sprint: No
Descoped date: 09/29/2022
Milestone: Milestone%201%20da40f3a1468c4ba6b3e76a3ab854a646.md
Planning Effort: 5
Productivity: JS%20b042281f5f16408e817b57b04ef125b6.md, JS%20a5a66517c6954eaa9936ad04f230ae09.md, JS%20611230dc2c2f47b4b29b89112afdc608.md, JS%20717184617337401f8b8388370218a4e0.md, JS%202d86be54ae0b4369b770417369a3a086.md
Sprints: Sprint%202%20427eb1e022d74213aeada09f56425209.md
Status: Descoped
Tags: Story