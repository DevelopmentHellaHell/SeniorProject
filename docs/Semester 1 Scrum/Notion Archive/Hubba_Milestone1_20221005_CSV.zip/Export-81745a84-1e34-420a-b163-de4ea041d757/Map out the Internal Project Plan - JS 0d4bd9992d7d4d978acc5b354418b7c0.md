# Map out the Internal Project Plan - JS

Assign: Jett Sonoda
Effort: 1.5
Priority: P2
Productivity: 6.5
Productivity Log: JS%208bd49cffb8f446fe828877203d2d4202.md, Untitled%20b108a08ae7e14f26b9149d27e0a56631.md, Untitled%20c7279c61c3d446f6874116f676bed666.md
Sprints: Sprint%203%20b3420b04fd6e40f580498d314d595ea6.md
Status: Done
Story: Project%20Plan%20v1%200a6a4e32bcff4379a00a3b4c055f7e32.md