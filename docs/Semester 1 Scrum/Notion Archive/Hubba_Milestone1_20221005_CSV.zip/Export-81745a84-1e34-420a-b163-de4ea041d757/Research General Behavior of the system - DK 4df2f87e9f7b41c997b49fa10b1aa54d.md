# Research General Behavior of the system - DK

Assign: Darius Koroni
Description: Document the findings of the general behavior which includes message format, web service style, input validation on frontend and backend, security, type of data storage, database tie-in, reference to error handling
Effort: 2
Priority: P3
Sprints: Sprint%203%20b3420b04fd6e40f580498d314d595ea6.md
Status: Done
Story: Research%20High-Level%20Design%2039c5c32464954d1ab6226f64ab78ebd9.md
Tag: Task