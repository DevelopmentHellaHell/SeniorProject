# Review Project Plan - DK

Assign: Darius Koroni
Description: -Review BRD and comment any questions or concerns
Effort: 1
Priority: P2
Productivity: 0.5
Productivity Log: Untitled%20500b21a6a35541279f059ae770983ab3.md
Sprints: Sprint%203%20b3420b04fd6e40f580498d314d595ea6.md
Status: Done
Story: Project%20Plan%20v1%200a6a4e32bcff4379a00a3b4c055f7e32.md
Tag: Task