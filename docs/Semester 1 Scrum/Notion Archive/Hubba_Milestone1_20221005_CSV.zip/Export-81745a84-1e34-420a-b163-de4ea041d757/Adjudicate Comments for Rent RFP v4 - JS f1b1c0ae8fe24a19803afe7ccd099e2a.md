# Adjudicate Comments for Rent RFP v4 - JS

Assign: Jett Sonoda
Description: Adjudicate comments from Bryan and Professor Vong
Should be fully reviewed before submission
Effort: 1
Productivity: 0.5
Productivity Log: JS%20f9459aa27a3046c8934915db721c57e9.md
Sprints: Sprint%202%2087f766b2aea949e0975d92e7109d70fb.md
Status: Done
Story: Hubba%20RFP%20v%201%204%203dfb96ff9b06473f9ea9a0a0f59ad05b.md
Tag: Task