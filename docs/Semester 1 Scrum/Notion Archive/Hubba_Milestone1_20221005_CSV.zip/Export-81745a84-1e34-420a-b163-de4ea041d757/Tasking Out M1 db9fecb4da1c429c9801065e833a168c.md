# Tasking Out M1

[Tasking Out M1](Tasking%20Out%20M1%200199e9d2471f4b63a97ebcb9c3df1c8e.csv)