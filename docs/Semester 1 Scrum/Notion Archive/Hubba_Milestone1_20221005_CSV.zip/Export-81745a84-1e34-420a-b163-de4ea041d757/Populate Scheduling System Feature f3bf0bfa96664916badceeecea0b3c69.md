# Populate Scheduling System Feature

Assign: Darius Koroni
Description: - Create Functional Requirements
- Create Non-functional Requirements
- Create Business Rules
- Create Verification/Error Handling Protocols
Effort: 5
Priority: P0
Productivity: 4.2
Productivity Log: DK%20a7e6d0150d3e42c1b7efff4d84c883c7.md, DK%20a52eb2eae57f45c1b7b7beb9cb10b094.md, DK%2089bace38018b4a00aa5b57f86ab436f4.md
Sprints: Sprint%202%2087f766b2aea949e0975d92e7109d70fb.md
Status: Done
Story: Business%20Requirements%20Document%20v2%20e951171d0bc74decb5d8739c91825d66.md
Tag: Task