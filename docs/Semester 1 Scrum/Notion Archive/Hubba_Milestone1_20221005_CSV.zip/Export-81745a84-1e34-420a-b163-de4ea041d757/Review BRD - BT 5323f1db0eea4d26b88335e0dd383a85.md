# Review BRD - BT

Assign: Bryan Tran
Description: -Review BRD and comment any questions or concerns
Effort: 2
Priority: P0
Sprints: Sprint%202%2087f766b2aea949e0975d92e7109d70fb.md, Sprint%203%20b3420b04fd6e40f580498d314d595ea6.md
Status: Done
Story: Business%20Requirements%20Document%20v2%20e951171d0bc74decb5d8739c91825d66.md
Tag: Task