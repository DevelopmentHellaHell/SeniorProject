# Populate Features and Scope - BT

Assign: Bryan Tran
Date: 09/23/2022
Description: Create the features, value of each feature, scope, and implementation
Effort: 2
Productivity: 5.5
Productivity Log: BT%2080568f1ea18940faa6719c7c3304791b.md, BT%20d474443858a94676900483d6213b32a6.md
Sprints: Sprint%201%20d66fa0a85732425da1a9452b3b9510a6.md
Status: Done
Story: Hubba%20RFP%20v%201%20771ed77e8aad493ca8fe6198ac1997fb.md
Tag: Task