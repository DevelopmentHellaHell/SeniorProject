# Research High-level design documents online

Assign: Kevin Dinh
Effort: 2.5
Priority: P4
Productivity: 3
Productivity Log: Untitled%20e7627f99bc7d4ad7ac6a42068c93bc33.md, Untitled%20f7ece497c9e044debba4b6d28814a741.md
Sprints: Sprint%203%20b3420b04fd6e40f580498d314d595ea6.md
Status: Done
Story: Research%20High-Level%20Design%20Document%20Format%20bf3ad20091334c0e9ce30e64054d490f.md
Tag: Task