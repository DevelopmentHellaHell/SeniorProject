# Adjudicate Comments for RFP v3 - BT

Assign: Bryan Tran
Description: Adjudicate all comments from Professor Vong’s email received on 9.27.2022.
Ensure all of the RFP is ready to be sent out for review.
Effort: 0.5
Productivity: 0.5
Productivity Log: BT%20616cb40e3bd14787893b221f47eacfef.md
Sprints: Sprint%202%2087f766b2aea949e0975d92e7109d70fb.md
Status: Done
Story: Hubba%20RFP%20v%201%203%20e9e43ced84894ae7b3eaba0a505fd5ed.md
Tag: Task