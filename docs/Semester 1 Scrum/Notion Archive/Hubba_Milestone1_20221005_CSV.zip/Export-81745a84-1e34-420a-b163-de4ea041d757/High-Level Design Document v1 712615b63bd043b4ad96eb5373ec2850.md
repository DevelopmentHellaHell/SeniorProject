# High-Level Design Document v1

Current Sprint: No
Descoped date: 10/06/2022
Milestone: Milestone%201%20da40f3a1468c4ba6b3e76a3ab854a646.md
Planning Effort: 15
Priority: P5
Productivity: TN%20e9b489f59f7745bca1b81506b210db34.md, Untitled%20e7627f99bc7d4ad7ac6a42068c93bc33.md, Untitled%20e0f14f8a4bb140e6b699f7375100ef9a.md
Sprints: Sprint%203%208eeed53a58604858a33e55908e967fd9.md
Status: Descoped
Tags: Story