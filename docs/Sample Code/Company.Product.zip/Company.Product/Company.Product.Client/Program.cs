﻿// See https://aka.ms/new-console-template for more information
using Company.Product.Logging;
Console.WriteLine("Hello, World!");

Console.ReadLine();