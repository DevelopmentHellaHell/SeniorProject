﻿namespace Company.Product.DAL
{
    public class SqlDataAccess
    {

    }
}