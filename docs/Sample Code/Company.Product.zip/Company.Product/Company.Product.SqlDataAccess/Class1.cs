﻿namespace Company.Product.SqlDataAccess
{
    public class Class1
    {

    }
}