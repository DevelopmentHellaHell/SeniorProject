﻿namespace Company.Product.Core
{
    public class DAL
    {

    }
}