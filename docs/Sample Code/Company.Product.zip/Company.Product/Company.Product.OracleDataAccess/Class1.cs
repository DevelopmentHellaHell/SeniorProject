﻿namespace Company.Product.OracleDataAccess
{
    public class Class1
    {

    }
}