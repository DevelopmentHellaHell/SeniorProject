﻿namespace Company.Product.Logging.Implementations
{
    public class DatabaseLogger
    {
        public DatabaseLogger()
        {

        }
        public DatabaseLogger(String tableName)
        {

        }

        public bool Log(string messsage)
        {
            // TODO: Log to database

            return true;
        }
    }
}