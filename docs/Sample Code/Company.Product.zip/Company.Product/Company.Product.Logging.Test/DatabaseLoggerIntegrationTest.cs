﻿using Company.Product.Logging.Implementations;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Company.Product.Logging.Tests
{
    [TestClass]
    public class DatabaseLoggerIntegrationTest
    {
        [TestMethod]
        public void ShouldLogWithin5Seconds()
        {
            // Arrange
            var stopwatch = new Stopwatch();
            var expected = 5;
            // system under test
            var sut = new DatabaseLogger();

            // Act
            stopwatch.Start();
            var logResult = sut.Log("Testing");
            stopwatch.Stop();

            // Turn ms to seconds
            var actual = stopwatch.ElapsedMilliseconds * 60_000;


            // Assert
            Assert.IsNotNull(actual);
            Assert.IsTrue(actual <= expected);
            Assert.IsTrue(logResult);
        }
    }
}
