using Company.Product.Logging.Implementations;

namespace Company.Product.Logging.Test
{
    [TestClass]
    public class DatabaseLoggerUnitTest
    {
        [TestMethod]
        //Front-end development naming convention
        public void ShouldCreateNewInstanceWithDefaultCtor()
        {
            // Arrange
            var expected = typeof(DatabaseLogger);

            // Act
            var actual = new DatabaseLogger();

            // Assert
            // First condition you should usually check for is null
            Assert.IsNotNull(actual);
            Assert.IsTrue(actual.GetType()==expected);

        }

        public void ShouldCreateNewInstanceWithParameterCtor()
        {
            // Arrange
            var expected = typeof(DatabaseLogger);
            var expectedTableName = "SomeTable";

            // Act
            var actual = new DatabaseLogger(expectedTableName);

            // Assert
            // First condition you should usually check for is null
            Assert.IsNotNull(actual);
            Assert.IsTrue(actual.GetType() == expected);

        }

        //Back-end development naming convention
        //public void Ctor_CreateNewInstance_Pass()
        //{

        //}
    }
}